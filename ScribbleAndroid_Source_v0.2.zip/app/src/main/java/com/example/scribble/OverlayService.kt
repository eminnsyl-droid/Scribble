package com.example.scribble

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.app.NotificationCompat

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var toolbar: View? = null
    private var toolbarParams: WindowManager.LayoutParams? = null
    private var canvasView: DrawingOverlayView? = null
    private var canvasParams: WindowManager.LayoutParams? = null
    private var drawingMode = false

    private val colors = intArrayOf(
        Color.RED, Color.YELLOW, Color.GREEN, Color.CYAN, Color.WHITE, Color.BLACK
    )
    private var colorIndex = 0
    private val widths = floatArrayOf(4f, 8f, 14f)
    private var widthIndex = 0

    private val passiveFlags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
        WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
    private val activeFlags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE

    override fun onCreate() {
        super.onCreate()
        createNotification()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        showToolbar()
    }

    private fun createNotification() {
        val channelId = "scribble_overlay"
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(channelId, "Scribble", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
        val notification: Notification = NotificationCompat.Builder(this, channelId)
            .setContentTitle("Scribble çalışıyor")
            .setContentText("Ekran üstü kalem araçları hazır")
            .setSmallIcon(android.R.drawable.ic_menu_edit)
            .setOngoing(true)
            .build()
        startForeground(7, notification)
    }

    private fun overlayParams(width: Int, height: Int, flags: Int): WindowManager.LayoutParams =
        WindowManager.LayoutParams(
            width, height, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            flags, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }

    // Çizim katmanı: tüm ekranı kaplar, başta dokunuşa kapalı (video normal kullanılır)
    private fun ensureCanvas(): DrawingOverlayView {
        canvasView?.let { return it }
        val view = DrawingOverlayView(this)
        val params = overlayParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            passiveFlags
        )
        wm.addView(view, params)
        canvasView = view
        canvasParams = params
        applyPenSettings()
        // Araç çubuğu her zaman çizim katmanının üstünde kalsın
        toolbar?.let { bar ->
            try { wm.removeView(bar) } catch (_: Exception) {}
            wm.addView(bar, toolbarParams)
        }
        return view
    }

    private fun applyPenSettings() {
        canvasView?.apply {
            penColor = colors[colorIndex]
            penWidth = widths[widthIndex]
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun showToolbar() {
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(8, 6, 8, 6)
            setBackgroundColor(Color.argb(225, 35, 39, 47))
        }

        // Sürükleme tutacağı
        val handle = TextView(this).apply {
            text = "⠿"
            textSize = 22f
            setTextColor(Color.WHITE)
            setPadding(16, 0, 16, 0)
            gravity = Gravity.CENTER
        }
        bar.addView(handle)

        fun addTool(label: String, action: (Button) -> Unit): Button {
            val b = Button(this).apply {
                text = label
                textSize = 12f
                isAllCaps = false
                minWidth = 0
                minimumWidth = 0
            }
            b.setOnClickListener { action(b) }
            bar.addView(b)
            return b
        }

        addTool("✎") { b ->
            toggleDrawing()
            b.text = if (drawingMode) "✎ AÇIK" else "✎"
        }
        addTool("Renk") { b ->
            colorIndex = (colorIndex + 1) % colors.size
            applyPenSettings()
            b.setTextColor(colors[colorIndex])
            b.setBackgroundColor(Color.DKGRAY)
        }
        addTool("Kalın") {
            widthIndex = (widthIndex + 1) % widths.size
            applyPenSettings()
        }
        addTool("Fosforlu") { b ->
            val v = ensureCanvas()
            v.highlighter = !v.highlighter
            b.text = if (v.highlighter) "Fosforlu ✓" else "Fosforlu"
        }
        addTool("Parmak: kapalı") { b ->
            val v = ensureCanvas()
            v.fingerDraws = !v.fingerDraws
            b.text = if (v.fingerDraws) "Parmak: açık" else "Parmak: kapalı"
        }
        addTool("↶") { canvasView?.undo() }
        addTool("↷") { canvasView?.redo() }
        addTool("Sil") { canvasView?.clear() }
        addTool("Kaydet") { canvasView?.saveToPictures(this) }
        addTool("×") { stopSelf() }

        val params = overlayParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            activeFlags
        ).apply { x = 200; y = 0 }

        // Tutaçtan sürükleyerek araç çubuğunu taşı
        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        handle.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    startX = params.x; startY = params.y
                    touchX = e.rawX; touchY = e.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = startX + (e.rawX - touchX).toInt()
                    params.y = startY + (e.rawY - touchY).toInt()
                    try { wm.updateViewLayout(bar, params) } catch (_: Exception) {}
                    true
                }
                else -> true
            }
        }

        toolbar = bar
        toolbarParams = params
        wm.addView(bar, params)
    }

    // ✎ açık: kalemle çizilir. Kapalı: çizimler görünür kalır ama dokunuşlar videoya geçer.
    private fun toggleDrawing() {
        drawingMode = !drawingMode
        val view = ensureCanvas()
        val params = canvasParams ?: return
        params.flags = if (drawingMode) activeFlags else passiveFlags
        wm.updateViewLayout(view, params)
    }

    override fun onDestroy() {
        try { toolbar?.let { wm.removeView(it) } } catch (_: Exception) {}
        try { canvasView?.let { wm.removeView(it) } } catch (_: Exception) {}
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
