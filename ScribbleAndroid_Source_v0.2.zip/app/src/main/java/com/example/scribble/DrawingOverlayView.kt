package com.example.scribble

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.os.Build
import android.provider.MediaStore
import android.view.MotionEvent
import android.view.View
import android.widget.Toast

class DrawingOverlayView(context: Context) : View(context) {
    private data class Stroke(val path: Path, val paint: Paint)

    private val strokes = mutableListOf<Stroke>()
    private val undone = mutableListOf<Stroke>()
    private var currentPath: Path? = null
    private var currentPaint = Paint()
    private var activePointerId = -1

    // Araç çubuğundan değiştirilen ayarlar
    var penColor: Int = Color.RED
    var penWidth: Float = 5f
    var highlighter: Boolean = false
    var fingerDraws: Boolean = false // false: sadece kalem çizer, parmak/avuç yok sayılır

    private fun makePaint(): Paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        if (highlighter) {
            color = Color.argb(100, Color.red(penColor), Color.green(penColor), Color.blue(penColor))
            strokeWidth = penWidth * 5f
        } else {
            color = penColor
            strokeWidth = penWidth
        }
    }

    init {
        setBackgroundColor(Color.TRANSPARENT)
        isClickable = true
    }

    private fun toolAllowed(toolType: Int): Boolean =
        toolType == MotionEvent.TOOL_TYPE_STYLUS ||
            (fingerDraws && toolType == MotionEvent.TOOL_TYPE_FINGER)

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        strokes.forEach { canvas.drawPath(it.path, it.paint) }
        currentPath?.let { canvas.drawPath(it, currentPaint) }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                if (currentPath != null) return true // zaten bir çizgi çiziliyor (avuç içi vb.)
                val idx = event.actionIndex
                if (!toolAllowed(event.getToolType(idx))) return true
                activePointerId = event.getPointerId(idx)
                val x = event.getX(idx)
                val y = event.getY(idx)
                currentPath = Path().apply {
                    moveTo(x, y)
                    lineTo(x + 0.1f, y) // tek dokunuşta nokta görünsün
                }
                currentPaint = makePaint()
                undone.clear()
                invalidate()
            }
            MotionEvent.ACTION_MOVE -> {
                val path = currentPath ?: return true
                val idx = event.findPointerIndex(activePointerId)
                if (idx < 0) return true
                for (h in 0 until event.historySize) {
                    path.lineTo(event.getHistoricalX(idx, h), event.getHistoricalY(idx, h))
                }
                path.lineTo(event.getX(idx), event.getY(idx))
                invalidate()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP, MotionEvent.ACTION_CANCEL -> {
                val idx = event.actionIndex
                if (event.actionMasked == MotionEvent.ACTION_CANCEL ||
                    event.getPointerId(idx) == activePointerId
                ) {
                    finishStroke()
                }
            }
        }
        return true
    }

    private fun finishStroke() {
        currentPath?.let { strokes.add(Stroke(it, currentPaint)) }
        currentPath = null
        activePointerId = -1
        invalidate()
    }

    fun clear() {
        strokes.clear()
        undone.clear()
        currentPath = null
        activePointerId = -1
        invalidate()
    }

    fun undo() {
        if (strokes.isNotEmpty()) {
            undone.add(strokes.removeAt(strokes.lastIndex))
            invalidate()
        }
    }

    fun redo() {
        if (undone.isNotEmpty()) {
            strokes.add(undone.removeAt(undone.lastIndex))
            invalidate()
        }
    }

    fun saveToPictures(context: Context) {
        if (width <= 0 || height <= 0 || strokes.isEmpty()) {
            Toast.makeText(context, "Kaydedilecek çizim yok.", Toast.LENGTH_SHORT).show()
            return
        }
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        strokes.forEach { canvas.drawPath(it.path, it.paint) }
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "Scribble-${System.currentTimeMillis()}.png")
            put(MediaStore.Images.Media.MIME_TYPE, "image/png")
            if (Build.VERSION.SDK_INT >= 29) {
                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Scribble")
            }
        }
        val uri = context.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
        if (uri != null) {
            context.contentResolver.openOutputStream(uri)?.use {
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, it)
            }
            Toast.makeText(context, "Resimlere kaydedildi.", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(context, "Kaydetme başarısız oldu.", Toast.LENGTH_SHORT).show()
        }
        bitmap.recycle()
    }
}
