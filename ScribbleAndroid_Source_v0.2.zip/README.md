# Scribble — Android başlangıç projesi

Bu, HONOR Pad X9a için hedeflenen ekran üstü çizim uygulamasının ilk kaynak kodu prototipidir.

## İçerik
- Ekran üstü görünme izni isteyen başlangıç ekranı
- Kullanıcı başlattığında foreground service ile kayan araç çubuğu
- Kalem modu açıldığında tam ekran şeffaf çizim katmanı
- Temizleme, geri alma ve PNG olarak Pictures/Scribble klasörüne kaydetme

## Derleme
1. Android Studio'da bu klasörü açın.
2. Android SDK 35 ve JDK 17 kurulu olduğundan emin olun.
3. Gradle senkronizasyonunu tamamlayın.
4. Build > Build Bundle(s) / APK(s) > Build APK(s) seçin.
5. APK'yı tablete aktarın ve kurun.

## v0.2 değişiklikleri
- Sadece kalemle çizim (parmak ve avuç içi yok sayılır; araç çubuğundan "Parmak" ile açılabilir)
- Renk, kalınlık, fosforlu kalem, ileri alma, sürüklenebilir araç çubuğu
- ✎ kapalıyken çizimler ekranda kalır, dokunuşlar alttaki uygulamaya (YouTube) geçer

## Bilinen prototip sınırlamaları
- Bu henüz test edilmiş/üretim sürümü değildir.
- İlk prototipte çizim katmanı aktifken ekrandaki dokunuşları kendisi yakalar; alttaki uygulamayı aynı anda kaydırmak için çizim modunu kapatmak gerekir.
- Kalem rengi/kalınlığı seçimi, fosforlu kalem, kalıcı oturumlar, ileri alma ve stylus/avuç içi optimizasyonu sonraki sürümlere bırakılmıştır.
- Android sürümüne ve üretici yazılımına göre foreground service/overlay izin davranışı değişebilir.
- Uygulama ilk açılışta Android'in ekran üstü izin sayfasını kullanır.
